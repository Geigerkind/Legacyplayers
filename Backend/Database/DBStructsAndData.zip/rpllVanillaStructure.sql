/*
SQLyog Community
MySQL - 8.0.11 : Database - rpll_vanilla
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `am_chars_data` */

DROP TABLE IF EXISTS `am_chars_data`;

CREATE TABLE `am_chars_data` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `charid` mediumint(8) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  `ref_misc` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ref_guild` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ref_honor` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ref_gear` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_am_chars_data` (`uploaderid`),
  KEY `FK2_am_chars_data` (`charid`),
  KEY `acd_refguild` (`ref_guild`),
  CONSTRAINT `FK_am_chars_data` FOREIGN KEY (`uploaderid`) REFERENCES `gn_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2587612 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_lifetimerank` */

DROP TABLE IF EXISTS `am_chars_lifetimerank`;

CREATE TABLE `am_chars_lifetimerank` (
  `charid` mediumint(8) unsigned NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`charid`),
  KEY `FK_am_chars_lifetimerank` (`uploaderid`),
  CONSTRAINT `FK_am_chars_lifetimerank` FOREIGN KEY (`uploaderid`) REFERENCES `gn_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_ref_gear` */

DROP TABLE IF EXISTS `am_chars_ref_gear`;

CREATE TABLE `am_chars_ref_gear` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `head` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `neck` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `shoulder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `shirt` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `chest` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `waist` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `legs` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `feet` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `wrist` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hands` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ring1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ring2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `trinket1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `trinket2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `back` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mainhand` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `offhand` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ranged` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tabard` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=816830 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_ref_gear_slot` */

DROP TABLE IF EXISTS `am_chars_ref_gear_slot`;

CREATE TABLE `am_chars_ref_gear_slot` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enchid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `genenchid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`)
) ENGINE=InnoDB AUTO_INCREMENT=124567 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_ref_guild` */

DROP TABLE IF EXISTS `am_chars_ref_guild`;

CREATE TABLE `am_chars_ref_guild` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `guildid` mediumint(8) unsigned NOT NULL,
  `grankindex` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grankname` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NoName',
  PRIMARY KEY (`id`),
  KEY `FK_am_chars_ref_guild` (`guildid`)
) ENGINE=InnoDB AUTO_INCREMENT=25227 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_ref_honor` */

DROP TABLE IF EXISTS `am_chars_ref_honor`;

CREATE TABLE `am_chars_ref_honor` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rank` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `progress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hk` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dk` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `honor` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `standing` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158998 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_chars_ref_misc` */

DROP TABLE IF EXISTS `am_chars_ref_misc`;

CREATE TABLE `am_chars_ref_misc` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `race` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `talents` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6714 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `am_guilds_progresshistory` */

DROP TABLE IF EXISTS `am_guilds_progresshistory`;

CREATE TABLE `am_guilds_progresshistory` (
  `id` int(11) unsigned NOT NULL DEFAULT '1',
  `guildid` mediumint(8) unsigned NOT NULL,
  `instanceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `npcid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attemptid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`instanceid`,`npcid`),
  KEY `FK_am_guilds_progresshistory2` (`attemptid`),
  CONSTRAINT `FK_am_guilds_progresshistory2` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_vanilla_enchantmentstats` */

DROP TABLE IF EXISTS `db_vanilla_enchantmentstats`;

CREATE TABLE `db_vanilla_enchantmentstats` (
  `enchid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(81) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `stat_type1` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_type2` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_type3` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`enchid`)
) ENGINE=InnoDB AUTO_INCREMENT=30781 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_vanilla_item_template` */

DROP TABLE IF EXISTS `db_vanilla_item_template`;

CREATE TABLE `db_vanilla_item_template` (
  `entry` mediumint(8) unsigned NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `icon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `quality` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `inventorytype` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `armor` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stat_type1` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value1` smallint(6) NOT NULL DEFAULT '0',
  `stat_type2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stat_value2` smallint(6) NOT NULL DEFAULT '0',
  `stat_type3` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value3` smallint(6) NOT NULL DEFAULT '0',
  `stat_type4` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value4` smallint(6) NOT NULL DEFAULT '0',
  `stat_type5` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value5` smallint(6) NOT NULL DEFAULT '0',
  `stat_type6` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value6` smallint(6) NOT NULL DEFAULT '0',
  `stat_type7` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value7` smallint(6) NOT NULL DEFAULT '0',
  `stat_type8` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value8` smallint(6) NOT NULL DEFAULT '0',
  `stat_type9` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value9` smallint(6) NOT NULL DEFAULT '0',
  `stat_type10` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `stat_value10` smallint(6) NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subclass` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `RequiredLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bonding` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sheath` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `itemset` smallint(5) unsigned NOT NULL DEFAULT '0',
  `MaxDurability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ItemLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dmg_min1` float unsigned NOT NULL DEFAULT '0',
  `dmg_max1` float unsigned NOT NULL DEFAULT '0',
  `dmg_type1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dmg_min2` float unsigned NOT NULL DEFAULT '0',
  `dmg_max2` float unsigned NOT NULL DEFAULT '0',
  `dmg_type2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dmg_min3` float unsigned NOT NULL DEFAULT '0',
  `dmg_max3` float unsigned NOT NULL DEFAULT '0',
  `dmg_type3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `extraTooltip` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `delay` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_vanilla_itemsets` */

DROP TABLE IF EXISTS `db_vanilla_itemsets`;

CREATE TABLE `db_vanilla_itemsets` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `setids` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `setnames` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `seteffectids` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `seteffectnames` varchar(550) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=552 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_vanilla_npcs` */

DROP TABLE IF EXISTS `db_vanilla_npcs`;

CREATE TABLE `db_vanilla_npcs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `family` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `friend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `deDE` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `frFR` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `zhCN` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `ruRU` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `esES` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `koKR` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200006 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_vanilla_spells` */

DROP TABLE IF EXISTS `db_vanilla_spells`;

CREATE TABLE `db_vanilla_spells` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(520) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `icon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `DispelCat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `spellCat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `duration` int(11) unsigned NOT NULL DEFAULT '0',
  `sourceid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tooltip` varchar(700) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `casttime` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108235 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_uploader` */

DROP TABLE IF EXISTS `gn_uploader`;

CREATE TABLE `gn_uploader` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL,
  `timestamp` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_gn_uploader` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=20978 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_attempts` */

DROP TABLE IF EXISTS `rs_attempts`;

CREATE TABLE `rs_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `npcid` mediumint(8) unsigned NOT NULL DEFAULT '3' COMMENT 'label?',
  `start` int(11) unsigned NOT NULL DEFAULT '0',
  `end` int(11) unsigned NOT NULL DEFAULT '0',
  `uploaderid` mediumint(8) unsigned NOT NULL,
  `killed` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0' COMMENT '0=>Attempt, 1=>Killed',
  PRIMARY KEY (`id`),
  KEY `FK_rs_attempts` (`uploaderid`),
  KEY `FK2_rs_attempts` (`npcid`),
  KEY `killed` (`killed`),
  CONSTRAINT `FK_rs_attempts` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1163 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_auras` */

DROP TABLE IF EXISTS `rs_auras`;

CREATE TABLE `rs_auras` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `said` int(11) unsigned NOT NULL,
  `gained` int(11) unsigned NOT NULL,
  `faded` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_auras` (`said`),
  CONSTRAINT `FK_rs_auras` FOREIGN KEY (`said`) REFERENCES `rs_sa_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=353187 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_bossyells` */

DROP TABLE IF EXISTS `rs_bossyells`;

CREATE TABLE `rs_bossyells` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `npcid` mediumint(8) unsigned NOT NULL,
  `yellid` smallint(5) unsigned NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_bossyells` (`uploaderid`),
  KEY `FK2_rs_bossyells` (`npcid`),
  KEY `FK3_rs_bossyells` (`yellid`),
  CONSTRAINT `FK2_rs_bossyells` FOREIGN KEY (`npcid`) REFERENCES `db_vanilla_npcs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_rs_bossyells` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1105 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_casts` */

DROP TABLE IF EXISTS `rs_casts`;

CREATE TABLE `rs_casts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `satid` int(11) unsigned NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_casts` (`satid`),
  CONSTRAINT `FK_rs_casts` FOREIGN KEY (`satid`) REFERENCES `rs_sat_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1266928 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_chars_rankings` */

DROP TABLE IF EXISTS `rs_chars_rankings`;

CREATE TABLE `rs_chars_rankings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `charid` mediumint(8) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL COMMENT '0=DPS,1=HPS,2=TPS',
  `value` int(11) unsigned NOT NULL DEFAULT '0',
  `attemptid` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_chars_rankings` (`charid`),
  KEY `FK2_rs_chars_rankings` (`attemptid`),
  CONSTRAINT `FK2_rs_chars_rankings` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15670 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_chars_rankings_best` */

DROP TABLE IF EXISTS `rs_chars_rankings_best`;

CREATE TABLE `rs_chars_rankings_best` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `charid` mediumint(8) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `value` int(11) unsigned NOT NULL DEFAULT '0',
  `attemptid` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_chars_rankings_best2` (`charid`),
  KEY `FK2_rs_chars_rankings_best2` (`attemptid`),
  CONSTRAINT `FK2_rs_chars_rankings_best2` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15611 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_damage` */

DROP TABLE IF EXISTS `rs_damage`;

CREATE TABLE `rs_damage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `satid` int(11) unsigned NOT NULL,
  `hittype` tinyint(2) unsigned NOT NULL COMMENT 'hit, crit, miss etc',
  `timestamp` int(11) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_rs_damage` (`satid`),
  CONSTRAINT `FK_rs_damage` FOREIGN KEY (`satid`) REFERENCES `rs_sat_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=406340 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_damage_mitgated` */

DROP TABLE IF EXISTS `rs_damage_mitgated`;

CREATE TABLE `rs_damage_mitgated` (
  `dmgid` int(11) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`dmgid`),
  CONSTRAINT `FK_rs_damage_mitgated` FOREIGN KEY (`dmgid`) REFERENCES `rs_damage` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_damage_threat` */

DROP TABLE IF EXISTS `rs_damage_threat`;

CREATE TABLE `rs_damage_threat` (
  `dmgid` int(11) unsigned NOT NULL,
  `amount` mediumint(9) unsigned NOT NULL,
  KEY `FK_rs_threat` (`dmgid`),
  CONSTRAINT `FK_rs_damage_threat` FOREIGN KEY (`dmgid`) REFERENCES `rs_damage` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_deaths` */

DROP TABLE IF EXISTS `rs_deaths`;

CREATE TABLE `rs_deaths` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sourceid` mediumint(8) unsigned NOT NULL COMMENT 'The one who died',
  `timestamp` int(11) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_deaths` (`uploaderid`),
  KEY `FK2_rs_deaths` (`sourceid`),
  CONSTRAINT `FK_rs_deaths` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4277 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_dispels` */

DROP TABLE IF EXISTS `rs_dispels`;

CREATE TABLE `rs_dispels` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sataid` int(11) unsigned NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_dispels` (`sataid`),
  CONSTRAINT `FK_rs_dispels` FOREIGN KEY (`sataid`) REFERENCES `rs_sata_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18781 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_gained_threat` */

DROP TABLE IF EXISTS `rs_gained_threat`;

CREATE TABLE `rs_gained_threat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `said` int(11) unsigned NOT NULL,
  `amount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_guilds_speedkills` */

DROP TABLE IF EXISTS `rs_guilds_speedkills`;

CREATE TABLE `rs_guilds_speedkills` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `attemptid` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_guilds_speedkills` (`attemptid`),
  CONSTRAINT `FK_rs_guilds_speedkills` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_guilds_speedkills_best` */

DROP TABLE IF EXISTS `rs_guilds_speedkills_best`;

CREATE TABLE `rs_guilds_speedkills_best` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `attemptid` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_guilds_speedkills_best` (`attemptid`),
  CONSTRAINT `FK_rs_guilds_speedkills_best` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_guilds_speedruns` */

DROP TABLE IF EXISTS `rs_guilds_speedruns`;

CREATE TABLE `rs_guilds_speedruns` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_guilds_speedruns` (`uploaderid`),
  CONSTRAINT `FK_rs_guilds_speedruns` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_guilds_speedruns_best` */

DROP TABLE IF EXISTS `rs_guilds_speedruns_best`;

CREATE TABLE `rs_guilds_speedruns_best` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_guilds_speedruns_best` (`uploaderid`),
  CONSTRAINT `FK_rs_guilds_speedruns_best` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_healing` */

DROP TABLE IF EXISTS `rs_healing`;

CREATE TABLE `rs_healing` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `satid` int(11) unsigned NOT NULL,
  `hittype` tinyint(2) unsigned NOT NULL COMMENT 'crit, hit',
  `timestamp` int(11) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_rs_healing` (`satid`),
  CONSTRAINT `FK_rs_healing` FOREIGN KEY (`satid`) REFERENCES `rs_sat_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99080 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_healing_threat` */

DROP TABLE IF EXISTS `rs_healing_threat`;

CREATE TABLE `rs_healing_threat` (
  `healid` int(11) unsigned NOT NULL,
  `amount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  KEY `FK_rs_healing_threat` (`healid`),
  CONSTRAINT `FK_rs_healing_threat` FOREIGN KEY (`healid`) REFERENCES `rs_healing` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_instance_uploader` */

DROP TABLE IF EXISTS `rs_instance_uploader`;

CREATE TABLE `rs_instance_uploader` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `instanceid` mediumint(8) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  `lookupspace` varchar(330) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `private` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_rs_instance_uploader` (`uploaderid`),
  KEY `FK2_rs_instance_uploader` (`instanceid`),
  CONSTRAINT `FK2_rs_instance_uploader` FOREIGN KEY (`instanceid`) REFERENCES `rs_instances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_rs_instance_uploader` FOREIGN KEY (`uploaderid`) REFERENCES `gn_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_instances` */

DROP TABLE IF EXISTS `rs_instances`;

CREATE TABLE `rs_instances` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `instanceid` smallint(5) unsigned NOT NULL,
  `guildid` mediumint(8) unsigned NOT NULL,
  `start` bigint(20) unsigned NOT NULL,
  `end` bigint(20) unsigned NOT NULL,
  `rdy` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `saveid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_rs_instances` (`guildid`),
  KEY `FK2_rs_instances` (`instanceid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_interrupts` */

DROP TABLE IF EXISTS `rs_interrupts`;

CREATE TABLE `rs_interrupts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sataid` int(11) unsigned NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_interrupts` (`sataid`),
  CONSTRAINT `FK_rs_interrupts` FOREIGN KEY (`sataid`) REFERENCES `rs_sata_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2950 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_loot` */

DROP TABLE IF EXISTS `rs_loot`;

CREATE TABLE `rs_loot` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `targetid` mediumint(8) unsigned NOT NULL,
  `itemid` mediumint(8) unsigned NOT NULL,
  `attemptid` int(11) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_loot` (`targetid`),
  KEY `FK2_rs_loot` (`uploaderid`),
  KEY `FK3_rs_loot` (`attemptid`),
  CONSTRAINT `FK2_rs_loot` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK3_rs_loot` FOREIGN KEY (`attemptid`) REFERENCES `rs_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=618 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_participants` */

DROP TABLE IF EXISTS `rs_participants`;

CREATE TABLE `rs_participants` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  `charid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rs_participants` (`uploaderid`),
  KEY `FK2_rs_participants` (`charid`),
  CONSTRAINT `FK_rs_participants` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1207 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_progress` */

DROP TABLE IF EXISTS `rs_progress`;

CREATE TABLE `rs_progress` (
  `uploaderid` mediumint(8) unsigned NOT NULL,
  `instanceid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `progress` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uploaderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_sa_reference` */

DROP TABLE IF EXISTS `rs_sa_reference`;

CREATE TABLE `rs_sa_reference` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sourceid` mediumint(8) unsigned NOT NULL,
  `abilityid` mediumint(8) unsigned NOT NULL,
  `uploaderid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup` (`sourceid`,`abilityid`,`uploaderid`),
  KEY `FK_rs_sa_reference` (`uploaderid`),
  KEY `FK2_rs_sa_reference` (`abilityid`),
  CONSTRAINT `FK2_rs_sa_reference` FOREIGN KEY (`abilityid`) REFERENCES `db_vanilla_spells` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_rs_sa_reference` FOREIGN KEY (`uploaderid`) REFERENCES `rs_instance_uploader` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14301 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_sat_reference` */

DROP TABLE IF EXISTS `rs_sat_reference`;

CREATE TABLE `rs_sat_reference` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `said` int(11) unsigned NOT NULL,
  `targetid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup` (`said`,`targetid`),
  CONSTRAINT `FK_rs_sat_reference` FOREIGN KEY (`said`) REFERENCES `rs_sa_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26107 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `rs_sata_reference` */

DROP TABLE IF EXISTS `rs_sata_reference`;

CREATE TABLE `rs_sata_reference` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `satid` int(11) unsigned NOT NULL,
  `targetabilityid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup` (`satid`,`targetabilityid`),
  CONSTRAINT `FK_rs_sata_reference` FOREIGN KEY (`satid`) REFERENCES `rs_sat_reference` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1363 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
