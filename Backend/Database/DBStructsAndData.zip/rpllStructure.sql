/*
SQLyog Community
MySQL - 8.0.11 : Database - rpll
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `db_icon_names` */

DROP TABLE IF EXISTS `db_icon_names`;

CREATE TABLE `db_icon_names` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5116 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_instances` */

DROP TABLE IF EXISTS `db_instances`;

CREATE TABLE `db_instances` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `map` smallint(5) unsigned NOT NULL,
  `israid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `enus` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `frfr` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `dede` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `zhcn` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `ruru` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `eses` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_item_displayid` */

DROP TABLE IF EXISTS `db_item_displayid`;

CREATE TABLE `db_item_displayid` (
  `id` mediumint(8) unsigned NOT NULL,
  `displayid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_servernames` */

DROP TABLE IF EXISTS `db_servernames`;

CREATE TABLE `db_servernames` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `expansion` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Crossfaction/Progressive etc.',
  `season` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `pvpreset` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pvereset` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `logon` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `contentlevel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_shortlink` */

DROP TABLE IF EXISTS `db_shortlink`;

CREATE TABLE `db_shortlink` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `data` varchar(2500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `db_yells` */

DROP TABLE IF EXISTS `db_yells`;

CREATE TABLE `db_yells` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `enus` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `frfr` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `dede` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `zhcn` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `ruru` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `eses` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8842 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_cachingcontroller` */

DROP TABLE IF EXISTS `gn_cachingcontroller`;

CREATE TABLE `gn_cachingcontroller` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_chars` */

DROP TABLE IF EXISTS `gn_chars`;

CREATE TABLE `gn_chars` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `serverid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `faction` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=>Horde, 1=>Alliance',
  `latestupdate` int(11) unsigned NOT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ownerid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Is pet?',
  `prof1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `prof2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_gn_chars` (`serverid`),
  KEY `FK_loadup` (`latestupdate`),
  KEY `gnchars_serverid` (`serverid`),
  CONSTRAINT `FK_gn_chars` FOREIGN KEY (`serverid`) REFERENCES `db_servernames` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=312686 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `gn_contact` */

DROP TABLE IF EXISTS `gn_contact`;

CREATE TABLE `gn_contact` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_deadlock` */

DROP TABLE IF EXISTS `gn_deadlock`;

CREATE TABLE `gn_deadlock` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_error` */

DROP TABLE IF EXISTS `gn_error`;

CREATE TABLE `gn_error` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `page` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_guilds` */

DROP TABLE IF EXISTS `gn_guilds`;

CREATE TABLE `gn_guilds` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `serverid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `faction` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=>Horde,1=>Alliance',
  `name` varchar(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NoName',
  PRIMARY KEY (`id`),
  KEY `FK_gn_guilds` (`serverid`),
  CONSTRAINT `FK_gn_guilds` FOREIGN KEY (`serverid`) REFERENCES `db_servernames` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=990 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_poll` */

DROP TABLE IF EXISTS `gn_poll`;

CREATE TABLE `gn_poll` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_supporters` */

DROP TABLE IF EXISTS `gn_supporters`;

CREATE TABLE `gn_supporters` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Anonnymous',
  `date` int(11) unsigned NOT NULL DEFAULT '0',
  `amount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `gn_user` */

DROP TABLE IF EXISTS `gn_user`;

CREATE TABLE `gn_user` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(51) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NoName',
  `accepted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=>No, 1=>Yes',
  `amount` int(11) unsigned NOT NULL DEFAULT '0',
  `registerd` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Unix Timestamp',
  `patreon` int(11) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Future reference',
  `ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `pass` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None' COMMENT 'bcrypt',
  `mail` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `lastcont` int(11) unsigned NOT NULL DEFAULT '0',
  `requestForgot` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `requestMail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `requestedMail` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'None',
  `uhash` varchar(121) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `disableads` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `defaultpriv` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pollselection` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2721 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
